from fastapi import FastAPI, Header, Depends, Request, HTTPException, status
import pandas as pd
from typing import Union, Optional
from pydantic import BaseModel
import requests
import tkinter as tk
from tkinter import *
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.responses import HTMLResponse
import tkinter.ttk as ttk
import secrets

security = HTTPBasic()
users_db = [
	{
		"username":"alice",
		"password": "wonderland"

	},
	{
		"username":"bob",
		"password": "builder"

	},
	{
		"username":"clementine",
		"password": "mandarine"

	},
]
admin_db = {
	"username":"admin",
	"password": "4dm1N"
}

data = pd.read_csv("questions.csv")
api = FastAPI()

def get_current_username(credentials: HTTPBasicCredentials=Depends(security)):
	for i in users_db:
		correct_username = secrets.compare_digest(credentials.username, i["username"])
		correct_password = secrets.compare_digest(credentials.password, i["password"])
		if correct_username & correct_password:
			return credentials.username
		if not (correct_username and correct_password):
			raise HTTPException(
				status_code = status.HTTP_401_UNAUTHORIZED,
				detail="Incorrect email or password",
				headers={"WWW-Authenticate":"Basic"},
			)															
@api.get("/welcome")
def read_current():
	"""
	return welcome url
	"""
	return "Hello"
	
@api.get("/status")
def status():
	r = requests.get("http://127.0.0.1:8000/welcome")
	if r.status_code == 200:
		"""
		return status of api
		"""
		return "1"
	else:
		"""
		return l'api ne fonctionne pas
		"""
		return "l'API ne fonctionne pas"
class Question(BaseModel):
	ask: str
	subject: str
	use: str
	responsA: str
	responsB: str
	responsC: str
	responsD: str
	
@api.put('/nquestions')
def put_questionn(question:Question, credentials: HTTPBasicCredentials= Depends(security)):
	correct_username = secrets.compare_digest(credentials.username, admin_db["username"])
	correct_password = secrets.compare_digest(credentials.password, admin_db['password'])
	
	if correct_username & correct_password:
		new_id = len(data)
		new_ques= {
			'ask':question.ask,
			'subject': question.subject,
			'use': question.use,
			'responsA':question.responsA,
			'responsB':question.responsB,
			'responsC':question.responsC,
			'responsD':question.responsD
		}
		data.append(new_ques, ignore_index=True)
		"""
		return la question nouvellement créee
		"""
		return new_ques
	if not (correct_username and correct_password):
		raise HTTPException(
			status_code = status.HTTP_401_UNAUTHORIZED,
			detail='Incorrect email or password',
			headers={"WWW-Authenticate":"Basic"},
			)
			
			
@api.get('/users/questions')
def get_user_qcm(username: str = Depends(get_current_username)):
	formation()

def formation():
	fenetrePrincipale = Tk()
	fenetrePrincipale.geometry('700x500')
	fenetrePrincipale.title("Générer des QCM")
	
	titre = tk.Label(fenetrePrincipale,
			text= "Bienvenue dans notre application de génération de QCM\n\n")
	titre.grid(column=5, row = 0)
	
	lapTop = tk.Label(fenetrePrincipale, text="Catégories1")
	lapTop.grid(column=5,row=3)
	
	ncat = tk.StringVar()
	menucat = ttk.Combobox(fenetrePrincipale, width=27, textvariable= ncat)
	menucat['values']= tuple(data["subject"].unique())
	menucat.grid(column=6, row=3)
	categorie= menucat.get()
	
	lapTop1 = tk.Label(fenetrePrincipale, text="Catégories2")
	lapTop1.grid(column=5, row=4)
	
	ncat1 = tk.StringVar()
	menucat1 = ttk.Combobox(fenetrePrincipale, width = 27, textvariable= ncat1)
	menucat1["values"]= tuple(data["subject"].unique())
	menucat1.grid(column = 6, row = 4)
	
	labelTyp = tk.Label(fenetrePrincipale, text = "Type")
	labelTyp.grid(column=5, row= 5)
	
	ntyp = tk.StringVar()
	menutyp = ttk.Combobox(fenetrePrincipale, width = 27, textvariable=ntyp)
	menutyp["values"]=tuple(data["use"].unique())
	menutyp.grid(column= 6, row=5)
	
	labelq = tk.Label(fenetrePrincipale, text="Question")
	labelq.grid(column=5,row=7)
	
	n =tk.StringVar()
	nquestion = ttk.Combobox(fenetrePrincipale, width = 27, textvariable = n)
	nquestion['values']=(5,10,20)
	nquestion.grid(column=6,row = 7)
	
	
	fenetrePrincipale.bind_all("<<ComboboxSelected>>", callbackFunc)
	
	fenetrePrincipale.mainloop()
	
d = []

def callbackFunc(event):
	valu = event.widget.get()
	d.append(valu)
	if len(d)==4:
		slct_quest = data.loc[(data["subject"]==d[0]) | (data["subject"]==d[1])]
		
		quest = slct_quest[["question", "responseA", "responseB", "responseC", "responseD"]]
		a = int(d[3])
		question_random = quest.sample(a)
		print(len(question_random))
		questionnaire = Tk()
		questionnaire.geometry('700x1000')
		questionnaire.title("Questionnaire")
		
		radioValue = tk.IntVar()
		x_l=5
		
		for i in question_random.index:
			labelTyp= tk.Label(questionnaire, text= question_random["question"][i])
			labelTyp.grid(column=5, row=x_l)
			
			rdioOne= tk.Radiobutton(questionnaire, text=question_random["responseA"][i],
						variable=radioValue, value= question_random["responseA"][i])
			rdioTwo = tk.Radiobutton(questionnaire, text= question_random["responseB"][i],
						variable=radioValue, value= question_random["responseB"][i])
			rdioThree = tk.Radiobutton(questionnaire, text= question_random["responseC"][i],
						variable=radioValue, value= question_random["responseC"][i])
			rdioFour = tk.Radiobutton(questionnaire, text = question_random["responseD"][i],
						variable=radioValue, value= question_random["responseD"][i])
	
			rdioOne.grid(column=5, row= x_l+1, sticky="W")
			rdioTwo.grid(column=5, row= x_l+2, sticky="W")
			rdioThree.grid(column=5, row= x_l+3, sticky="W")
			rdioFour.grid(column=5, row= x_l+4, sticky="W")			
			x_l = x_l + 5
		questionnaire.mainloop()
			
	
	

			
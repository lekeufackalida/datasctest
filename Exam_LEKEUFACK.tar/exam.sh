#!/bin/bash

myfunction() {
date >> /home/ubuntu/Exam_LEKEUFACK/sales.txt
for carte in rtx3060 rtx3070 rtx3080 rtx3090 rx6700
do

    
    nb_cb=$(curl "http://0.0.0.0:5000/$carte")
    echo "$carte:$nb_cb" >> /home/ubuntu/Exam_LEKEUFACK/sales.txt 
done }

myfunction

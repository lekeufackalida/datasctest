from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python import PythonOperator
import os
import json


def get_weather():

    ville=['paris','london','washington']
    for city in ville:
# My API key is defined in my config.py file.
        paramaters = {'q':city , 'appid':'62ee8788e06f7ba0e7bd21472c4b16df'}

        result     = requests.get("http://api.openweathermap.org/data/2.5/weather?", paramaters)
    #25237a5210330ad588a2a33c388da468
    # If the API call was sucessful, get the json and dump it to a file with 
    # today's date as the title.
        if result.status_code == 200 :
    # Get the json data 
            json_data = result.json()
    # print(json_data)

    # create directory
            createDirectory()

    # make file 
            filename = "raw_files/" + str(datetime.now()) + '.json'    

            with open(filename, 'w') as file:
                print(filename)
                json.dump(json_data, file)
                print(json_data)
                print("closing file . . . ")            

        else :
            print ("Error In API call.")

        
def createDirectory():
    # creating directory 
    dirName = "raw_files"
    
    # create target directory if don't exists    
    if not os.path.exists(dirName):
    # exception handeling for file not found
        try:
            os.makedirs(dirName)
            print("Directory ", dirName, "Created")

        except FileExistsError as fe:
            print("Error : ", fe)
            print("Directory ", dirName, "already exists")


def transform_data_into_csv(n_files=None, filename='data.csv'):
    parent_folder = 'raw_files'
    files = sorted(os.listdir(parent_folder), reverse=True)
    if n_files:
        files = files[:n_files]

    dfs = []

    for f in files:
        with open(os.path.join(parent_folder, f), 'r') as file:
            data_temp = json.load(file)
            dfs.append(
                {
                    'temperature': data_temp['main']['temp'],
                    'city': data_temp['name'],
                    'pression': data_temp['main']['pressure'],
                    'date': f.split('.')[0]
                }
            )

    df = pd.DataFrame(dfs)

    print('\n', df.head(10))

    df.to_csv(os.path.join('clean_data', filename), index=False)


def compute_model_score(model, X, y):
    # computing cross val
    cross_validation = cross_val_score(
        model,
        X,
        y,
        cv=3,
        scoring='neg_mean_squared_error')

    model_score = cross_validation.mean()

    return model_score


def train_and_save_model(model, X, y, path_to_model='./app/model.pckl'):
    # training the model
    model.fit(X, y)
    # saving model
    print(str(model), 'saved at ', path_to_model)
    
    dump(model, path_to_model)


def prepare_data(path_to_data='./app/clean_data/fulldata.csv'):
    # reading data
    df = pd.read_csv(path_to_data)
    # ordering data according to city and date
    df = df.sort_values(['city', 'date'], ascending=True)

    dfs = []

    for c in df['city'].unique():
        df_temp = df[df['city'] == c]

        # creating target
        df_temp.loc[:, 'target'] = df_temp['temperature'].shift(1)

        # creating features
        for i in range(1, 10):
            df_temp.loc[:, 'temp_m-{}'.format(i)
                        ] = df_temp['temperature'].shift(-i)

        # deleting null values
        df_temp = df_temp.dropna()

        dfs.append(df_temp)

    # concatenating datasets
    df_final = pd.concat(
        dfs,
        axis=0,
        ignore_index=False
    )

    # deleting date variable
    df_final = df_final.drop(['date'], axis=1)

    # creating dummies for city variable
    df_final = pd.get_dummies(df_final)

    features = df_final.drop(['target'], axis=1)
    target = df_final['target']

    return features, target



##########
#task_instance.xcom_push(
       # key="my_xcom_value",
        #value=random.uniform(a=0, b=1)
    #)
#########""""


def task4_1(task_instance):

    X, y = prepare_data('clean_data/fulldata.csv')

    score_lr = compute_model_score(LinearRegression(), X, y)
    task_instance.xcom_push(
        key="score_lr",
        value=score_lr
    )

def task4_2(task_instance):
    X, y = prepare_data('clean_data/fulldata.csv')

    score_dt = compute_model_score(DecisionTreeRegressor(), X, y)
    task_instance.xcom_push(
        key="score_dt",
        value=score_dt
    )

def task4_3(task_instance):
    X, y = prepare_data('clean_data/fulldata.csv')

    score_rf = compute_model_score(RandomForestRegressor(), X, y)
    task_instance.xcom_push(
        key="score_rf",
        value=score_rf
    )

def task5(task_instance):
    score_lr =  task_instance.xcom_pull(key="score_lr")
    score_dt =  task_instance.xcom_pull(key="score_dt")
    score_rf =  task_instance.xcom_pull(key="score_rf")
    if score_lr>=score_dt:
        if score_lr >= score_rf:
            train_and_save_model(
            LinearRegression(),
            X,
            y,
            'clean_data/best_model.pickle'
        )
        else:
            train_and_save_model(
            RandomForestRegressor(),
            X,
            y,
            'clean_data/best_model.pickle'
        )
    else:
        if score_dt>=score_rf:
            train_and_save_model(
            DecisionTreeRegressor(),
            X,
            y,
            'clean_data/best_model.pickle'
        )
        else:
            train_and_save_model(
            RandomForestRegressor(),
            X,
            y,
            'clean_data/best_model.pickle'
        )


##########    




# defining the default arguments
default_args = {
    'owner':'Alida',
    'depends_on_past': False,
    'email_on_failure':False,
    'email_on_retry':False,
    'retries':1,
    'retry_delay':timedelta(minutes=1)
    }


# define the dag, the start date how frequently it starts 
dag = DAG(
    dag_id = 'weather_load_dag',
    default_args=default_args,
    start_date = datetime(2022,6,2),
    schedule_interval = '*/1 * * * *'#timedelta(minutes = 1)
)

# First task is to query data from the openweather.org
task1 = PythonOperator(
    task_id = 'get_weather',
    dag = dag,
    python_callable=get_weather
)

# Second task is to process the data and load into the database
task2 = PythonOperator(
    task_id='load_data2',
    dag=dag,
    python_callable=transform_data_into_csv, op_args=[20,'data.csv']
)
task3 = PythonOperator(
    task_id='load_data3',
    dag=dag,
    python_callable=transform_data_into_csv, op_args=[None,'fulldata.csv']
)

task4_1 = PythonOperator(
    task_id='score_1',
    dag=dag,
    python_callable=task4_1
)
task4_2 = PythonOperator(
    task_id='score_2',
    dag=dag,
    python_callable=task4_2
)
task4_3 = PythonOperator(
    task_id='score_3',
    dag=dag,
    python_callable=task4_3
)

task5 = PythonOperator(
    task_id='meilleur_score',
    dag=dag,
    python_callable=task5
)


task1 >> task2 >> task3 >> [task4_1, task4_2, task4_3] >> task5

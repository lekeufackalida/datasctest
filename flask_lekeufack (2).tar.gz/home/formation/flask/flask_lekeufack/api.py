from flask  import Flask, render_template, request
import requests
import pandas as pd
from pydantic import BaseModel
from flask_pydantic import validate
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from werkzeug.exceptions import Unauthorized,BadRequest
from flask_httpauth import HTTPBasicAuth




app = Flask(__name__)



data = pd.read_csv("credentials.csv")



@app.route("/status")
def status():
    r = requests.get('http://127.0.0.1:5000/welcome')
    if r.status_code == 200:
        return "1"


#marche




@app.route("/welcome", methods =["GET"])
def perm1():
    username = request.args.get('username')
    return "hello {}".format(username)


@app.route("/permissions", methods=["POST"])
def perm():
    d = request.get_json()
    username = d['username']
    username = str(username)
    password = d['password']
    password = int(password)
    userr = data.loc[(data["username"] == username) & (data["password"] == password)].reset_index(drop = True)
    userr_size = len(userr)
    if userr_size != 0:
        
        if userr["v1"][0] == 1:
            return "hello {}, vous avez accès à la version 1".format(userr["username"][0])
        elif userr["v2"][0] != 0:
            return "hello {}, vous avez accès à la version 2".format(userr["username"][0])
        elif (userr["v1"][0] != 0) & (userr["v2"][0] != 0):
            return "hello {}, vous avez accès à la version 1 et 2".format(userr["username"][0])
    
        else :
            return "hello {}, vous n'avez accès à aucune version".format(userr["username"][0])
    else:
        raise BadRequest("code: 400 cette utilisateur n'existe pas")
    
       

@app.route("/v1/sentiment", methods = ["GET","POST"])
def vader():
    sentence = request.args.get('sentence')
    username = request.args.get('username')
    username = str(username)
    password = request.args.get('password')
    password = int(password)

    userr = data.loc[(data["username"] == username) & (data["password"] == password)].reset_index(drop = True)
    taille = len(userr)

    if taille != 0:
        if userr["v1"][0] == 1 : 
            analyzer = SentimentIntensityAnalyzer()
            vs = analyzer.polarity_scores(sentence)
            return "{:-<65} {}".format(sentence, str(vs))
        else:
            return "vous n'avez pas accès à cette version"
    else:
        raise BadRequest("code:400 vous assayez d'accéder à un module non autorisé")
   
    
@app.route("/v2/sentiment", methods = ["GET","POST"])
def vader2():
    sentence = request.request.get('sentence')
    username = request.request.get('username')
    username = str(username)
    password = request.args.get('password')
    password = int(password)

    userr = data.loc[(data["username"] == username) & (data["password"] == password)].reset_index(drop = True)
    taille = len(userr)

    if taille != 0:
        if userr["v2"][0] == 1 :
            sentence = request.args.get('sentence')
            analyzer = SentimentIntensityAnalyzer()
            vs = analyzer.polarity_scores(sentence)
            #compound :str(vs["compound"]))
            return "{:-<65} compound: {}".format(sentence, str(vs))
        else:
            return "vous n'avez pas accès à cette version"
    else :
        raise BadRequest("code 400: vous assayez d'accéder à un module non autorisé")



from flask  import Flask, render_template, request
import requests
import pandas as pd
from pydantic import BaseModel
from flask_pydantic import validate
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from werkzeug.exceptions import Unauthorized,BadRequest
from flask_httpauth import HTTPBasicAuth




app = Flask(__name__)



data = pd.read_csv("credentials.csv")



@app.route("/status")
def status():
    r = requests.get('http://127.0.0.1:5000/welcome')
    if r.status_code == 200:
        return "1"


#marche




@app.route("/welcome", methods =["GET"])
def perm1():
    username = request.args.get('username')
    return "hello {}".format(username)


@app.route("/permissions", methods=["POST"])
def perm():
    d = request.get_json()
    username = d['username']
    username = str(username)
    password = d['password']
    password = int(password)
    userr = data.loc[(data["username"] == username) & (data["password"] == password)].reset_index(drop = True)
    userr_size = len(userr)
    if userr_size != 0:

        if (userr["v1"][0] != 0) & (userr["v2"][0] != 0):
            return "hello {}, vous avez accès à la version 1 et 2".format(userr["username"][0])
        
        elif userr["v1"][0] == 1:
            return "hello {}, vous avez accès à la version 1".format(userr["username"][0])
        elif userr["v2"][0] != 0:
            return "hello {}, vous avez accès à la version 2".format(userr["username"][0])
        
    
        else :
            return "hello {}, vous n'avez accès à aucune version".format(userr["username"][0])
    else:
        raise BadRequest("code: 400 cette utilisateur n'existe pas")
    
       

@app.route("/v1/sentiment", methods = ["POST"])
def vader():
    
    
    d = request.headers.get('username')
    x = d.split("=")

    sentences = request.get_json('sentence') 
    sentence = sentences["sentence"]
    username = x[0]
    username = str(username)
    password = x[1]
    password = int(password)


    userr = data.loc[(data["username"] == username) & (data["password"] == password)].reset_index(drop = True)
    taille = len(userr)

    if taille != 0:
        if userr["v1"][0] == 1 : 
            analyzer = SentimentIntensityAnalyzer()
            vs = analyzer.polarity_scores(sentence)
            return "{}".format(str(vs))
            
        else:
            return "vous n'avez pas accès à cette version"
    else:
        raise BadRequest("code:400 vous assayez d'accéder à un module non autorisé")
   
    
@app.route("/v2/sentiment", methods = ["POST"])
def vader2():

    d = request.headers.get('username')
    x = d.split("=")

    sentences = request.get_json('sentence') 
    sentence = sentences["sentence"]
    username = x[0]
    username = str(username)
    password = x[1]
    password = int(password)

    userr = data.loc[(data["username"] == username) & (data["password"] == password)].reset_index(drop = True)
    taille = len(userr)

    if taille != 0:
        if userr["v2"][0] == 1 :
            
            analyzer = SentimentIntensityAnalyzer()
            vs = analyzer.polarity_scores(sentence)
            #compound :str(vs["compound"]))
            
            return "{:-<65} compound: {}".format(sentence, str(vs))
        else:
            return "vous n'avez pas accès à cette version"
    else :
        raise BadRequest("code 400: vous assayez d'accéder à un module non autorisé")




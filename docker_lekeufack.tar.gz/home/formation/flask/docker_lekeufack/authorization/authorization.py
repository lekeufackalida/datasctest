import os
import requests

api_address = os.environ.get("APP_URL")

# requête
r = requests.get(
    url=f'{api_address}/v1/sentiment',
    params= {
        'username': 'alice',
        'password': 'wonderland',
        'sentence': 'life is beautiful'
        
    }
)

r2 = requests.get(
    url=f'{api_address}/v2/sentiment',
    params= {
        'username': 'alice',
        'password': 'wonderland',
        'sentence': 'that sucks'
        
    }
)

output = '''
============================
    Authorization test
============================

request done at "/v1/sentiment"
| username="alice"
| password="wonderland"

expected result = 200
actual restult = {status_code}

==>  {test_status}
'''
output2 = '''
request done at "/v2/sentiment"
| username="alice"
| password="wonderland"

expected result = 200
actual restult = {status_code2}

==>  {test_status2}

'''


# statut de la requête
status_code = r.status_code
status_code2 = r2.status_code

# affichage des résultats pour la version v1
if status_code == 200:
    test_status = 'SUCCESS'
else:
    test_status = 'FAILURE'
print(output.format(status_code=status_code, test_status=test_status))

# impression dans un fichier
if os.environ.get('LOG') == 1:
    with open('api_test.log', 'a') as file:
        file.write(output)


# affichage des résultats pour la version v2
if status_code2 == 200:
    test_status2 = 'SUCCESS'
else:
    test_status2 = 'FAILURE'
print(output2.format(status_code2=status_code2, test_status2=test_status2))

# impression dans un fichier
if os.environ.get('LOG') == 1:
    with open('api_test.log', 'a') as file:
        file.write(output2)
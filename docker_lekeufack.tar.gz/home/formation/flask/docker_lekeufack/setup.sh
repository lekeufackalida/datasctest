#!/bin/bash
#construire image

sudo su 
cd Authentication
docker build -t authentication:latest .
cd ..
cd authorization
docker build -t authorization:latest .
cd ..
cd content
docker build -t content:latest .
cd ..
docker-compose up
